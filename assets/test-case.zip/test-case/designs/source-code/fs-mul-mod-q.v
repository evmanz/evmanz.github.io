module fs_mul_mod_q (
    input  [31:0] multiplicand, // N-bit input a
    input  [31:0] multiplier,   // N-bit input b
    input  [31:0] q,            // Modulus q (at most 32 bits)
    input  [4:0]  l1,           // 5-bit l1
    input  [4:0]  l2,           // 5-bit l2
    input  [4:0]  l3,           // 5-bit l3
    input  [4:0]  omega,        // omega
    output [31:0] product,      // N-bit sum output
    output        error         // Error signal
);

    wire [63:0] product_wire;
    wire mul_error, red_error;
    fs_mul u_fs_mul (
        .multiplicand(multiplicand),
        .multiplier(multiplier),
        .product(product_wire),
        .error(mul_error)
    );

    // Instantiate the original module
    fs_reduce_mod_q u_reduce_mod_q (
        .a(product_wire),
        .q(q),
        .l1(l1),
        .l2(l2),
        .l3(l3),
        .omega(omega),
        .b(product),
        .error(red_error)
    );
    assign error = mul_error | red_error;
endmodule

module fs_mul_mod_q_wrapper (
    input  clk,                 // Clock signal
    input  reset,                 // Synchronous reset
    input  [31:0] multiplicand, // N-bit input a
    input  [31:0] multiplier,   // N-bit input b
    input  [31:0] q,            // Modulus q (at most 32 bits)
    input  [4:0]  l1,           // 5-bit l1
    input  [4:0]  l2,           // 5-bit l2
    input  [4:0]  l3,           // 5-bit l3
    input  [4:0]  omega,        // omega
    output [31:0] product,      // N-bit sum output
    output        error         // Error signal
);

    // Registered inputs
    reg [31:0] multiplicand_reg, multiplier_reg, q_reg, product_reg;
    reg [4:0] l1_reg, l2_reg, l3_reg, omega_reg;
    
    wire [31:0] product_wire;
    wire error_wire;
    reg error_reg;

    // Input registers
    always @(posedge clk) begin
        if (reset) begin
            multiplicand_reg <= 0;
            multiplier_reg <= 0;
            q_reg <= 0;
            l1_reg <= 0;
            l2_reg <= 0;
            l3_reg <= 0;
            omega_reg <= 0;
            product_reg <= 0;
            error_reg <= 0;
        end else begin
            multiplicand_reg <= multiplicand;
            multiplier_reg <= multiplier;
            q_reg <= q;
            l1_reg <= l1;
            l2_reg <= l2;
            l3_reg <= l3;
            omega_reg <= omega;
            product_reg <= product_wire;
            error_reg <= error_wire;
        end
    end

    // Instantiation of ripple carry adder
    fs_mul_mod_q u_fs_mul_mod_q (
        .multiplicand(multiplicand_reg),
        .multiplier(multiplier_reg),
        .q(q_reg),
        .l1(l1_reg),
        .l2(l2_reg),
        .l3(l3_reg),
        .omega(omega_reg),
        .product(product_wire),
        .error(error_wire)
    );

    assign product = product_reg;
    assign error = error_reg;
endmodule
// synthesis translate_off
module fs_tb_mul_mod_q;
    // Testbench parameters
    parameter Q = 32'd3204710401; // Modulus Q (ensure Q < 2^32)
    parameter NUM_TESTS = 100;  // Number of random test cases
    
    // Inputs
    reg [64:0] multiplicand;
    reg [64:0] multiplier;
    reg [31:0] q;
    reg [4:0] l1;
    reg [4:0] l2;
    reg [4:0] l3;
    reg [4:0] omega;
    reg [32:0] R;
    reg [32:0] R_INV;

    // Output
    wire [31:0] product;
    wire error_wire;
    // Instantiate the DUT (Device Under Test)
    fs_mul_mod_q dut (
        .multiplicand(multiplicand[31:0]),
        .multiplier(multiplier[31:0]),
        .q(q),
        .l1(l1),
        .l2(l2),
        .l3(l3),
        .omega(omega),
        .product(product), 
        .error(error_wire)
    );

    reg [31:0] a, b;
    reg [64:0] expected, actual;
    // Randomized test procedure
    initial begin
        $dumpfile("fs_tb_mul_mod_q.vcd");
        $dumpvars(0, fs_tb_mul_mod_q);        
        $display("Starting testbench...");
        R = 1<<32;  // Set the scaling factor R
        R_INV = 32'd2391210000;  // Set the R inverse mod Q
        q = 32'd3204710401;  // Set the modulus Q
        l1 = 5'd14; // Set l1 (can be tuned for the Montgomery reduction)
        l2 = 5'd8; // Set l2 (can be tuned for the Montgomery reduction)
        l3 = 5'd2; // Set l3 (can be tuned for the Montgomery reduction)
        omega = 5'd16; // Set omega (can be tuned for the Montgomery reduction)

        for (integer i = 0; i < NUM_TESTS; i++) begin
            // Generate random inputs
            a = $random % Q;  // Ensure values are less than Q
            b = $random % Q;

            // Convert to Montgomery form
            multiplicand = (a * R) % Q;
            multiplier = (b * R) % Q;
            // Wait for result
            #10;

            // Compute expected result
            expected = (a * b) % Q;

            // Convert DUT output back from Montgomery form
            actual = (product * R_INV) % Q;
            
            // Compare results
            if (actual !== expected) begin
                $error("\tTest %0d failed: a=%0d, b=%0d, expected=%0d, actual=%0d", i, a, b, expected, actual);
            end

            if (error_wire) begin
                $error("\tTest %0d failed: error = %0d", i, error_wire);
            end
        end
        $display("All tests completed.");
        $finish;
    end
endmodule
// synthesis translate_on