export DESIGN_NICKNAME = fs-mul-mod-q
export DESIGN_NAME = fs_mul_mod_q_wrapper
export PLATFORM    = asap7

export VERILOG_FILES = $(sort $(wildcard ./designs/source-code/fs*.v))
export SDC_FILE      = ./designs/$(PLATFORM)/$(DESIGN_NICKNAME)/constraint.sdc

export CORE_UTILIZATION = 20
export CORE_ASPECT_RATIO = 1
export CORE_MARGIN = 5

export PLACE_DENSITY_LB_ADDON = 0.20
