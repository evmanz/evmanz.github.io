// Generated Wallace Tree Multiplier

module partial_product_generator (
    input  [32:0] multiplicand,
    input  [2:0] encode,
    input  [5:0] shift,
    output [65:0] partial_product
);
    reg [65:0] pp_temp;
    always @(*) begin
        case (encode)
            3'd0: pp_temp = 66'd0;
            3'd1: pp_temp = {33'd0, multiplicand};       // +M
            3'd2: pp_temp = {33'd0, multiplicand} << 1; // +2M
            3'd7: pp_temp = -{33'd0, multiplicand};      // -M
            3'd6: pp_temp = -({33'd0, multiplicand} << 1); // -2M
            default: pp_temp = 66'd0;
        endcase
    end
    assign partial_product = pp_temp << shift;
endmodule
module booth_encoder (
    input  [2:0] booth_bits,
    output [2:0] encode
);
    assign encode = (booth_bits == 3'b000 || booth_bits == 3'b111) ? 3'd0 : // 0
                (booth_bits == 3'b001 || booth_bits == 3'b010) ? 3'd1 : // +M
                (booth_bits == 3'b011)                     ? 3'd2 : // +2M
                (booth_bits == 3'b100)                     ? 3'd6 : // -2M
                (booth_bits == 3'b101 || booth_bits == 3'b110) ? 3'd7 : // -M
                3'd0;  // Default
endmodule
module fs_mul (
    input  [31:0] multiplicand,
    input  [31:0] multiplier,
    output [63:0] product,
    output error
);

    // Partial products
    wire [65:0] pp [16:0];

    wire [32:0] ext_multiplicand = {1'b0, multiplicand};

    wire [32:0] ext_multiplier = {1'b0, multiplier};

    (* keep *) wire [16:0] booth_enc_error;
    // Booth encoding for pp[0]
    wire [2:0] booth_bits_0 = {ext_multiplier[1], ext_multiplier[0], 1'b0};
    wire [2:0] encode_0;
    booth_encoder BE_0 (
        .booth_bits(booth_bits_0),
        .encode(encode_0)
    );
    wire [2:0] dup_encode_0;
    (* keep *) booth_encoder dup_BE_0 (
        .booth_bits(booth_bits_0),
        .encode(dup_encode_0)
    );
    assign booth_enc_error[0] = (^dup_encode_0) ^ (^encode_0);
    partial_product_generator PPG_0 (
        .multiplicand(ext_multiplicand),
        .encode(encode_0),
        .shift(6'b000000),
        .partial_product(pp[0])
    );

    // Booth encoding for pp[1]
    wire [2:0] booth_bits_1 = {ext_multiplier[3], ext_multiplier[2], ext_multiplier[1]};
    wire [2:0] encode_1;
    booth_encoder BE_1 (
        .booth_bits(booth_bits_1),
        .encode(encode_1)
    );
    wire [2:0] dup_encode_1;
    (* keep *) booth_encoder dup_BE_1 (
        .booth_bits(booth_bits_1),
        .encode(dup_encode_1)
    );
    assign booth_enc_error[1] = (^dup_encode_1) ^ (^encode_1);
    partial_product_generator PPG_1 (
        .multiplicand(ext_multiplicand),
        .encode(encode_1),
        .shift(6'b000010),
        .partial_product(pp[1])
    );

    // Booth encoding for pp[2]
    wire [2:0] booth_bits_2 = {ext_multiplier[5], ext_multiplier[4], ext_multiplier[3]};
    wire [2:0] encode_2;
    booth_encoder BE_2 (
        .booth_bits(booth_bits_2),
        .encode(encode_2)
    );
    wire [2:0] dup_encode_2;
    (* keep *) booth_encoder dup_BE_2 (
        .booth_bits(booth_bits_2),
        .encode(dup_encode_2)
    );
    assign booth_enc_error[2] = (^dup_encode_2) ^ (^encode_2);
    partial_product_generator PPG_2 (
        .multiplicand(ext_multiplicand),
        .encode(encode_2),
        .shift(6'b000100),
        .partial_product(pp[2])
    );

    // Booth encoding for pp[3]
    wire [2:0] booth_bits_3 = {ext_multiplier[7], ext_multiplier[6], ext_multiplier[5]};
    wire [2:0] encode_3;
    booth_encoder BE_3 (
        .booth_bits(booth_bits_3),
        .encode(encode_3)
    );
    wire [2:0] dup_encode_3;
    (* keep *) booth_encoder dup_BE_3 (
        .booth_bits(booth_bits_3),
        .encode(dup_encode_3)
    );
    assign booth_enc_error[3] = (^dup_encode_3) ^ (^encode_3);
    partial_product_generator PPG_3 (
        .multiplicand(ext_multiplicand),
        .encode(encode_3),
        .shift(6'b000110),
        .partial_product(pp[3])
    );

    // Booth encoding for pp[4]
    wire [2:0] booth_bits_4 = {ext_multiplier[9], ext_multiplier[8], ext_multiplier[7]};
    wire [2:0] encode_4;
    booth_encoder BE_4 (
        .booth_bits(booth_bits_4),
        .encode(encode_4)
    );
    wire [2:0] dup_encode_4;
    (* keep *) booth_encoder dup_BE_4 (
        .booth_bits(booth_bits_4),
        .encode(dup_encode_4)
    );
    assign booth_enc_error[4] = (^dup_encode_4) ^ (^encode_4);
    partial_product_generator PPG_4 (
        .multiplicand(ext_multiplicand),
        .encode(encode_4),
        .shift(6'b001000),
        .partial_product(pp[4])
    );

    // Booth encoding for pp[5]
    wire [2:0] booth_bits_5 = {ext_multiplier[11], ext_multiplier[10], ext_multiplier[9]};
    wire [2:0] encode_5;
    booth_encoder BE_5 (
        .booth_bits(booth_bits_5),
        .encode(encode_5)
    );
    wire [2:0] dup_encode_5;
    (* keep *) booth_encoder dup_BE_5 (
        .booth_bits(booth_bits_5),
        .encode(dup_encode_5)
    );
    assign booth_enc_error[5] = (^dup_encode_5) ^ (^encode_5);
    partial_product_generator PPG_5 (
        .multiplicand(ext_multiplicand),
        .encode(encode_5),
        .shift(6'b001010),
        .partial_product(pp[5])
    );

    // Booth encoding for pp[6]
    wire [2:0] booth_bits_6 = {ext_multiplier[13], ext_multiplier[12], ext_multiplier[11]};
    wire [2:0] encode_6;
    booth_encoder BE_6 (
        .booth_bits(booth_bits_6),
        .encode(encode_6)
    );
    wire [2:0] dup_encode_6;
    (* keep *) booth_encoder dup_BE_6 (
        .booth_bits(booth_bits_6),
        .encode(dup_encode_6)
    );
    assign booth_enc_error[6] = (^dup_encode_6) ^ (^encode_6);
    partial_product_generator PPG_6 (
        .multiplicand(ext_multiplicand),
        .encode(encode_6),
        .shift(6'b001100),
        .partial_product(pp[6])
    );

    // Booth encoding for pp[7]
    wire [2:0] booth_bits_7 = {ext_multiplier[15], ext_multiplier[14], ext_multiplier[13]};
    wire [2:0] encode_7;
    booth_encoder BE_7 (
        .booth_bits(booth_bits_7),
        .encode(encode_7)
    );
    wire [2:0] dup_encode_7;
    (* keep *) booth_encoder dup_BE_7 (
        .booth_bits(booth_bits_7),
        .encode(dup_encode_7)
    );
    assign booth_enc_error[7] = (^dup_encode_7) ^ (^encode_7);
    partial_product_generator PPG_7 (
        .multiplicand(ext_multiplicand),
        .encode(encode_7),
        .shift(6'b001110),
        .partial_product(pp[7])
    );

    // Booth encoding for pp[8]
    wire [2:0] booth_bits_8 = {ext_multiplier[17], ext_multiplier[16], ext_multiplier[15]};
    wire [2:0] encode_8;
    booth_encoder BE_8 (
        .booth_bits(booth_bits_8),
        .encode(encode_8)
    );
    wire [2:0] dup_encode_8;
    (* keep *) booth_encoder dup_BE_8 (
        .booth_bits(booth_bits_8),
        .encode(dup_encode_8)
    );
    assign booth_enc_error[8] = (^dup_encode_8) ^ (^encode_8);
    partial_product_generator PPG_8 (
        .multiplicand(ext_multiplicand),
        .encode(encode_8),
        .shift(6'b010000),
        .partial_product(pp[8])
    );

    // Booth encoding for pp[9]
    wire [2:0] booth_bits_9 = {ext_multiplier[19], ext_multiplier[18], ext_multiplier[17]};
    wire [2:0] encode_9;
    booth_encoder BE_9 (
        .booth_bits(booth_bits_9),
        .encode(encode_9)
    );
    wire [2:0] dup_encode_9;
    (* keep *) booth_encoder dup_BE_9 (
        .booth_bits(booth_bits_9),
        .encode(dup_encode_9)
    );
    assign booth_enc_error[9] = (^dup_encode_9) ^ (^encode_9);
    partial_product_generator PPG_9 (
        .multiplicand(ext_multiplicand),
        .encode(encode_9),
        .shift(6'b010010),
        .partial_product(pp[9])
    );

    // Booth encoding for pp[10]
    wire [2:0] booth_bits_10 = {ext_multiplier[21], ext_multiplier[20], ext_multiplier[19]};
    wire [2:0] encode_10;
    booth_encoder BE_10 (
        .booth_bits(booth_bits_10),
        .encode(encode_10)
    );
    wire [2:0] dup_encode_10;
    (* keep *) booth_encoder dup_BE_10 (
        .booth_bits(booth_bits_10),
        .encode(dup_encode_10)
    );
    assign booth_enc_error[10] = (^dup_encode_10) ^ (^encode_10);
    partial_product_generator PPG_10 (
        .multiplicand(ext_multiplicand),
        .encode(encode_10),
        .shift(6'b010100),
        .partial_product(pp[10])
    );

    // Booth encoding for pp[11]
    wire [2:0] booth_bits_11 = {ext_multiplier[23], ext_multiplier[22], ext_multiplier[21]};
    wire [2:0] encode_11;
    booth_encoder BE_11 (
        .booth_bits(booth_bits_11),
        .encode(encode_11)
    );
    wire [2:0] dup_encode_11;
    (* keep *) booth_encoder dup_BE_11 (
        .booth_bits(booth_bits_11),
        .encode(dup_encode_11)
    );
    assign booth_enc_error[11] = (^dup_encode_11) ^ (^encode_11);
    partial_product_generator PPG_11 (
        .multiplicand(ext_multiplicand),
        .encode(encode_11),
        .shift(6'b010110),
        .partial_product(pp[11])
    );

    // Booth encoding for pp[12]
    wire [2:0] booth_bits_12 = {ext_multiplier[25], ext_multiplier[24], ext_multiplier[23]};
    wire [2:0] encode_12;
    booth_encoder BE_12 (
        .booth_bits(booth_bits_12),
        .encode(encode_12)
    );
    wire [2:0] dup_encode_12;
    (* keep *) booth_encoder dup_BE_12 (
        .booth_bits(booth_bits_12),
        .encode(dup_encode_12)
    );
    assign booth_enc_error[12] = (^dup_encode_12) ^ (^encode_12);
    partial_product_generator PPG_12 (
        .multiplicand(ext_multiplicand),
        .encode(encode_12),
        .shift(6'b011000),
        .partial_product(pp[12])
    );

    // Booth encoding for pp[13]
    wire [2:0] booth_bits_13 = {ext_multiplier[27], ext_multiplier[26], ext_multiplier[25]};
    wire [2:0] encode_13;
    booth_encoder BE_13 (
        .booth_bits(booth_bits_13),
        .encode(encode_13)
    );
    wire [2:0] dup_encode_13;
    (* keep *) booth_encoder dup_BE_13 (
        .booth_bits(booth_bits_13),
        .encode(dup_encode_13)
    );
    assign booth_enc_error[13] = (^dup_encode_13) ^ (^encode_13);
    partial_product_generator PPG_13 (
        .multiplicand(ext_multiplicand),
        .encode(encode_13),
        .shift(6'b011010),
        .partial_product(pp[13])
    );

    // Booth encoding for pp[14]
    wire [2:0] booth_bits_14 = {ext_multiplier[29], ext_multiplier[28], ext_multiplier[27]};
    wire [2:0] encode_14;
    booth_encoder BE_14 (
        .booth_bits(booth_bits_14),
        .encode(encode_14)
    );
    wire [2:0] dup_encode_14;
    (* keep *) booth_encoder dup_BE_14 (
        .booth_bits(booth_bits_14),
        .encode(dup_encode_14)
    );
    assign booth_enc_error[14] = (^dup_encode_14) ^ (^encode_14);
    partial_product_generator PPG_14 (
        .multiplicand(ext_multiplicand),
        .encode(encode_14),
        .shift(6'b011100),
        .partial_product(pp[14])
    );

    // Booth encoding for pp[15]
    wire [2:0] booth_bits_15 = {ext_multiplier[31], ext_multiplier[30], ext_multiplier[29]};
    wire [2:0] encode_15;
    booth_encoder BE_15 (
        .booth_bits(booth_bits_15),
        .encode(encode_15)
    );
    wire [2:0] dup_encode_15;
    (* keep *) booth_encoder dup_BE_15 (
        .booth_bits(booth_bits_15),
        .encode(dup_encode_15)
    );
    assign booth_enc_error[15] = (^dup_encode_15) ^ (^encode_15);
    partial_product_generator PPG_15 (
        .multiplicand(ext_multiplicand),
        .encode(encode_15),
        .shift(6'b011110),
        .partial_product(pp[15])
    );

    // Booth encoding for pp[16]
    wire [2:0] booth_bits_16 = {1'b0, ext_multiplier[32], ext_multiplier[31]};
    wire [2:0] encode_16;
    booth_encoder BE_16 (
        .booth_bits(booth_bits_16),
        .encode(encode_16)
    );
    wire [2:0] dup_encode_16;
    (* keep *) booth_encoder dup_BE_16 (
        .booth_bits(booth_bits_16),
        .encode(dup_encode_16)
    );
    assign booth_enc_error[16] = (^dup_encode_16) ^ (^encode_16);
    partial_product_generator PPG_16 (
        .multiplicand(ext_multiplicand),
        .encode(encode_16),
        .shift(6'b100000),
        .partial_product(pp[16])
    );

    // Wallace tree reduction
    // Level 1 CSA 0
    wire [65:0] sum_L1_0, carry_L1_0;
    wire [65:0] pcp_carry_L1_0;
    wire pcpin_L1_0 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L1_0 (
        .in1(pp[0]),
        .in2(pp[1]),
        .in3(pp[2]),
        .pcpin(pcpin_L1_0),
        .sum(sum_L1_0),
        .cout(carry_L1_0),
        .pcpout(pcp_carry_L1_0) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_1_0;
    assign error_1_0 = (carry_L1_0 ^ (~pcp_carry_L1_0)) ^ (pp[0] ^ pp[1] ^ pp[2] ^ sum_L1_0);
    // Level 1 CSA 1
    wire [65:0] sum_L1_1, carry_L1_1;
    wire [65:0] pcp_carry_L1_1;
    wire pcpin_L1_1 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L1_1 (
        .in1(pp[3]),
        .in2(pp[4]),
        .in3(pp[5]),
        .pcpin(pcpin_L1_1),
        .sum(sum_L1_1),
        .cout(carry_L1_1),
        .pcpout(pcp_carry_L1_1) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_1_1;
    assign error_1_1 = (carry_L1_1 ^ (~pcp_carry_L1_1)) ^ (pp[3] ^ pp[4] ^ pp[5] ^ sum_L1_1);
    // Level 1 CSA 2
    wire [65:0] sum_L1_2, carry_L1_2;
    wire [65:0] pcp_carry_L1_2;
    wire pcpin_L1_2 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L1_2 (
        .in1(pp[6]),
        .in2(pp[7]),
        .in3(pp[8]),
        .pcpin(pcpin_L1_2),
        .sum(sum_L1_2),
        .cout(carry_L1_2),
        .pcpout(pcp_carry_L1_2) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_1_2;
    assign error_1_2 = (carry_L1_2 ^ (~pcp_carry_L1_2)) ^ (pp[6] ^ pp[7] ^ pp[8] ^ sum_L1_2);
    // Level 1 CSA 3
    wire [65:0] sum_L1_3, carry_L1_3;
    wire [65:0] pcp_carry_L1_3;
    wire pcpin_L1_3 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L1_3 (
        .in1(pp[9]),
        .in2(pp[10]),
        .in3(pp[11]),
        .pcpin(pcpin_L1_3),
        .sum(sum_L1_3),
        .cout(carry_L1_3),
        .pcpout(pcp_carry_L1_3) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_1_3;
    assign error_1_3 = (carry_L1_3 ^ (~pcp_carry_L1_3)) ^ (pp[9] ^ pp[10] ^ pp[11] ^ sum_L1_3);
    // Level 1 CSA 4
    wire [65:0] sum_L1_4, carry_L1_4;
    wire [65:0] pcp_carry_L1_4;
    wire pcpin_L1_4 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L1_4 (
        .in1(pp[12]),
        .in2(pp[13]),
        .in3(pp[14]),
        .pcpin(pcpin_L1_4),
        .sum(sum_L1_4),
        .cout(carry_L1_4),
        .pcpout(pcp_carry_L1_4) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_1_4;
    assign error_1_4 = (carry_L1_4 ^ (~pcp_carry_L1_4)) ^ (pp[12] ^ pp[13] ^ pp[14] ^ sum_L1_4);
    // Level 2 CSA 0
    wire [65:0] sum_L2_0, carry_L2_0;
    wire [65:0] pcp_carry_L2_0;
    wire pcpin_L2_0 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L2_0 (
        .in1(sum_L1_0),
        .in2(/*shifting left by 1*/{carry_L1_0[64:0], 1'b0}),
        .in3(sum_L1_1),
        .pcpin(pcpin_L2_0),
        .sum(sum_L2_0),
        .cout(carry_L2_0),
        .pcpout(pcp_carry_L2_0) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_2_0;
    assign error_2_0 = (carry_L2_0 ^ (~pcp_carry_L2_0)) ^ (sum_L1_0 ^ /*shifting left by 1*/{carry_L1_0[64:0], 1'b0} ^ sum_L1_1 ^ sum_L2_0);
    // Level 2 CSA 1
    wire [65:0] sum_L2_1, carry_L2_1;
    wire [65:0] pcp_carry_L2_1;
    wire pcpin_L2_1 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L2_1 (
        .in1(/*shifting left by 1*/{carry_L1_1[64:0], 1'b0}),
        .in2(sum_L1_2),
        .in3(/*shifting left by 1*/{carry_L1_2[64:0], 1'b0}),
        .pcpin(pcpin_L2_1),
        .sum(sum_L2_1),
        .cout(carry_L2_1),
        .pcpout(pcp_carry_L2_1) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_2_1;
    assign error_2_1 = (carry_L2_1 ^ (~pcp_carry_L2_1)) ^ (/*shifting left by 1*/{carry_L1_1[64:0], 1'b0} ^ sum_L1_2 ^ /*shifting left by 1*/{carry_L1_2[64:0], 1'b0} ^ sum_L2_1);
    // Level 2 CSA 2
    wire [65:0] sum_L2_2, carry_L2_2;
    wire [65:0] pcp_carry_L2_2;
    wire pcpin_L2_2 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L2_2 (
        .in1(sum_L1_3),
        .in2(/*shifting left by 1*/{carry_L1_3[64:0], 1'b0}),
        .in3(sum_L1_4),
        .pcpin(pcpin_L2_2),
        .sum(sum_L2_2),
        .cout(carry_L2_2),
        .pcpout(pcp_carry_L2_2) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_2_2;
    assign error_2_2 = (carry_L2_2 ^ (~pcp_carry_L2_2)) ^ (sum_L1_3 ^ /*shifting left by 1*/{carry_L1_3[64:0], 1'b0} ^ sum_L1_4 ^ sum_L2_2);
    // Level 2 CSA 3
    wire [65:0] sum_L2_3, carry_L2_3;
    wire [65:0] pcp_carry_L2_3;
    wire pcpin_L2_3 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L2_3 (
        .in1(/*shifting left by 1*/{carry_L1_4[64:0], 1'b0}),
        .in2(pp[15]),
        .in3(pp[16]),
        .pcpin(pcpin_L2_3),
        .sum(sum_L2_3),
        .cout(carry_L2_3),
        .pcpout(pcp_carry_L2_3) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_2_3;
    assign error_2_3 = (carry_L2_3 ^ (~pcp_carry_L2_3)) ^ (/*shifting left by 1*/{carry_L1_4[64:0], 1'b0} ^ pp[15] ^ pp[16] ^ sum_L2_3);
    // Level 3 CSA 0
    wire [65:0] sum_L3_0, carry_L3_0;
    wire [65:0] pcp_carry_L3_0;
    wire pcpin_L3_0 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L3_0 (
        .in1(sum_L2_0),
        .in2(/*shifting left by 1*/{carry_L2_0[64:0], 1'b0}),
        .in3(sum_L2_1),
        .pcpin(pcpin_L3_0),
        .sum(sum_L3_0),
        .cout(carry_L3_0),
        .pcpout(pcp_carry_L3_0) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_3_0;
    assign error_3_0 = (carry_L3_0 ^ (~pcp_carry_L3_0)) ^ (sum_L2_0 ^ /*shifting left by 1*/{carry_L2_0[64:0], 1'b0} ^ sum_L2_1 ^ sum_L3_0);
    // Level 3 CSA 1
    wire [65:0] sum_L3_1, carry_L3_1;
    wire [65:0] pcp_carry_L3_1;
    wire pcpin_L3_1 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L3_1 (
        .in1(/*shifting left by 1*/{carry_L2_1[64:0], 1'b0}),
        .in2(sum_L2_2),
        .in3(/*shifting left by 1*/{carry_L2_2[64:0], 1'b0}),
        .pcpin(pcpin_L3_1),
        .sum(sum_L3_1),
        .cout(carry_L3_1),
        .pcpout(pcp_carry_L3_1) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_3_1;
    assign error_3_1 = (carry_L3_1 ^ (~pcp_carry_L3_1)) ^ (/*shifting left by 1*/{carry_L2_1[64:0], 1'b0} ^ sum_L2_2 ^ /*shifting left by 1*/{carry_L2_2[64:0], 1'b0} ^ sum_L3_1);
    // Level 4 CSA 0
    wire [65:0] sum_L4_0, carry_L4_0;
    wire [65:0] pcp_carry_L4_0;
    wire pcpin_L4_0 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L4_0 (
        .in1(sum_L3_0),
        .in2(/*shifting left by 1*/{carry_L3_0[64:0], 1'b0}),
        .in3(sum_L3_1),
        .pcpin(pcpin_L4_0),
        .sum(sum_L4_0),
        .cout(carry_L4_0),
        .pcpout(pcp_carry_L4_0) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_4_0;
    assign error_4_0 = (carry_L4_0 ^ (~pcp_carry_L4_0)) ^ (sum_L3_0 ^ /*shifting left by 1*/{carry_L3_0[64:0], 1'b0} ^ sum_L3_1 ^ sum_L4_0);
    // Level 4 CSA 1
    wire [65:0] sum_L4_1, carry_L4_1;
    wire [65:0] pcp_carry_L4_1;
    wire pcpin_L4_1 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L4_1 (
        .in1(/*shifting left by 1*/{carry_L3_1[64:0], 1'b0}),
        .in2(sum_L2_3),
        .in3(/*shifting left by 1*/{carry_L2_3[64:0], 1'b0}),
        .pcpin(pcpin_L4_1),
        .sum(sum_L4_1),
        .cout(carry_L4_1),
        .pcpout(pcp_carry_L4_1) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_4_1;
    assign error_4_1 = (carry_L4_1 ^ (~pcp_carry_L4_1)) ^ (/*shifting left by 1*/{carry_L3_1[64:0], 1'b0} ^ sum_L2_3 ^ /*shifting left by 1*/{carry_L2_3[64:0], 1'b0} ^ sum_L4_1);
    // Level 5 CSA 0
    wire [65:0] sum_L5_0, carry_L5_0;
    wire [65:0] pcp_carry_L5_0;
    wire pcpin_L5_0 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L5_0 (
        .in1(sum_L4_0),
        .in2(/*shifting left by 1*/{carry_L4_0[64:0], 1'b0}),
        .in3(sum_L4_1),
        .pcpin(pcpin_L5_0),
        .sum(sum_L5_0),
        .cout(carry_L5_0),
        .pcpout(pcp_carry_L5_0) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_5_0;
    assign error_5_0 = (carry_L5_0 ^ (~pcp_carry_L5_0)) ^ (sum_L4_0 ^ /*shifting left by 1*/{carry_L4_0[64:0], 1'b0} ^ sum_L4_1 ^ sum_L5_0);
    // Level 6 CSA 0
    wire [65:0] sum_L6_0, carry_L6_0;
    wire [65:0] pcp_carry_L6_0;
    wire pcpin_L6_0 = 1'b0;
    fs_carry_save_adder #(.N(66)) CSA_L6_0 (
        .in1(sum_L5_0),
        .in2(/*shifting left by 1*/{carry_L5_0[64:0], 1'b0}),
        .in3(/*shifting left by 1*/{carry_L4_1[64:0], 1'b0}),
        .pcpin(pcpin_L6_0),
        .sum(sum_L6_0),
        .cout(carry_L6_0),
        .pcpout(pcp_carry_L6_0) // Assuming pcpout corresponds to sum; adjust if needed
    );
    wire [65:0] error_6_0;
    assign error_6_0 = (carry_L6_0 ^ (~pcp_carry_L6_0)) ^ (sum_L5_0 ^ /*shifting left by 1*/{carry_L5_0[64:0], 1'b0} ^ /*shifting left by 1*/{carry_L4_1[64:0], 1'b0} ^ sum_L6_0);

    // Final addition
    wire [65:0] pcp_final;
    assign product = sum_L6_0 + /*shifting left by 1*/{carry_L6_0[64:0], 1'b0};
    assign error = (|booth_enc_error) | (|error_1_0) | (|error_1_1) | (|error_1_2) | (|error_1_3) | (|error_1_4) | (|error_2_0) | (|error_2_1) | (|error_2_2) | (|error_2_3) | (|error_3_0) | (|error_3_1) | (|error_4_0) | (|error_4_1) | (|error_5_0) | (|error_6_0);

endmodule
module fs_mul_wrapper (
    input             clk,
    input             reset,
    input  [31:0]     multiplicand,
    input  [31:0]     multiplier,
    output [63:0] result,
    output error

);

    // Registers for inputs
    reg [31:0] multiplicand_reg;
    reg [31:0] multiplier_reg;
    
    // Register for the product
    reg [63:0] product_reg;
    reg error_reg;

    // Product wire (from the main multiplier logic)
    wire [63:0] product;
    wire error_wire;

    // Instantiate the Booth-Wallace multiplier logic as a submodule
    fs_mul multiplier_inst (
        .multiplicand(multiplicand_reg),
        .multiplier(multiplier_reg),
        .product(product),
        .error(error_wire)
    );

    // Sequential logic
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            // Reset all registers
            multiplicand_reg <= 32'b0;
            multiplier_reg   <= 32'b0;
            product_reg      <= 63'b0;
            // result           <= 63'b0;
            error_reg        <= 1'b0;
        end else begin
            // Latch inputs
            multiplicand_reg <= multiplicand;
            multiplier_reg   <= multiplier;

            // Latch product
            product_reg <= product;
            error_reg <= error_wire;

            // Drive final output
            // result <= product_reg[63:0];
            // error <= error_reg;
        end
    end
    assign result = product_reg[63:0];
    assign error = error_reg;
endmodule
    
// synthesis translate_off
module tb_fs_mul_testbench;
    reg  [31:0] multiplicand;
    reg  [31:0] multiplier;
    wire [63:0] product;
    wire error;

    fs_mul uut (
        .multiplicand(multiplicand),
        .multiplier(multiplier),
        .product(product),
        .error(error)
    );

    integer i;
    reg [63:0] expected_product;

    initial begin
        $dumpfile("tb_fs_mul_testbench.vcd");
        $dumpvars(0, tb_fs_mul_testbench);
        $display("Testing Unsigned Wallace Tree Multiplier with Random Inputs");
        for (i = 0; i < 10; i = i + 1) begin
            multiplicand = $random & (-1+(1<<32)); // Generate random positive numbers
            multiplier   = $random & (-1+(1<<32));
            #10;
            expected_product = multiplicand * multiplier;
                
            if (product !== expected_product) begin
                $display("Test %0d:", i+1);
                $display("Multiplicand: %0d", multiplicand);
                $display("Multiplier:   %0d", multiplier);
                $display("Expected Product: %0d", expected_product);
                $display("Calculated Product: %0d", product);
                $display("ERROR: Incorrect product!");
            end 
            if (error !== 1'b0) begin
                $display("Test %0d:", i+1);
                $display("Multiplicand: %0d", multiplicand);
                $display("Multiplier:   %0d", multiplier);
                $display("Expected Product: %0d", expected_product);
                $display("Calculated Product: %0d", product);
                $display("ERROR: Error signal is %0d!", error);
            end
            // else begin
            //     $display("PASS");
            // end
            // $display("-----------------------------");
        end
        $finish;
    end
endmodule
// synthesis translate_on

