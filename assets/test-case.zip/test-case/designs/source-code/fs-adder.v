module fs_main_adder #(parameter N = 4) ( // Parameterized for N-bit addition
    input  [N-1:0] a,       // N-bit input a
    input  [N-1:0] b,       // N-bit input b
    input          cin,     // Carry-in
    input          pcpin,   // Parity-check input
    output [N-1:0] sum,     // N-bit sum output
    output         cout,    // Carry-out
    output         error       // Parity-check sum output
);

    wire [N:0] carry; // Carry signals, N+1 for carry-out
    wire [N-1:0] pcp; // Intermediate parity check signals

    assign carry[0] = cin; // Initial carry-in

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : FA_STAGE
            fs_fa fa_inst (
                .a(a[i]),
                .b(b[i]),
                .cin(carry[i]),
                .pcpin((i == 0) ? pcpin : pcp[i-1]), // Input pcpin for the first stage
                .sum(sum[i]),
                .cout(carry[i+1]),
                .pcpout(pcp[i])
            );
        end
    endgenerate

    assign cout = carry[N];  // Final carry-out
    assign error = (cout ^ pcp[N-1] ^ cin ^ (^a) ^ (^b)) ^ (^sum); // Parity-check sum output

endmodule

module fs_adder_wrapper #(parameter N = 32) (
    input clk,             // Clock signal
    input reset,             // Synchronous reset
    input [N-1:0] a,       // N-bit input a
    input [N-1:0] b,       // N-bit input b
    input cin,             // Carry-in
    input pcpin,           // Parity-check input
    output [N-1:0] sum_reg_sample, // Registered sum output
    output cout_reg_sample,        // Registered carry-out
    output error_reg_sample       // Registered parity-check output
);

    // Registered inputs
    reg [N-1:0] a_reg, b_reg;
    reg cin_reg, pcpin_reg;

    // Output wires
    wire [N-1:0] sum;
    wire cout, error;

    // Registered outputs
    reg [N-1:0] sum_reg_sample;
    reg cout_reg_sample;
    reg error_reg_sample;

    // Input registers
    always @(posedge clk) begin
        if (reset) begin
            a_reg <= 0;
            b_reg <= 0;
            cin_reg <= 0;
            pcpin_reg <= 0;
        end else begin
            a_reg <= a;
            b_reg <= b;
            cin_reg <= cin;
            pcpin_reg <= pcpin;
        end
    end

    // Instantiation of ripple carry adder
    fs_main_adder #(N) rca (
        .a(a_reg),
        .b(b_reg),
        .cin(cin_reg),
        .pcpin(pcpin_reg),
        .sum(sum),
        .cout(cout),
        .error(error)
    );

    // Output registers
    always @(posedge clk) begin
        if (reset) begin
            sum_reg_sample <= 0;
            cout_reg_sample <= 0;
            error_reg_sample <= 0;
        end else begin
            sum_reg_sample <= sum;
            cout_reg_sample <= cout;
            error_reg_sample <= error;
        end
    end

endmodule

// synthesis translate_off
module tb_fs_main_adder;

    parameter N = 16; // Number of bits for the adder

    reg [N-1:0] a;       // N-bit input a
    reg [N-1:0] b;       // N-bit input b
    reg cin;             // Carry-in
    reg pcpin;           // Parity-check input

    wire [N-1:0] sum;    // N-bit sum output
    wire cout;           // Carry-out
    wire error;             // Parity-check sum output

    // DUT instantiation
    fs_main_adder #(N) dut (
        .a(a),
        .b(b),
        .cin(cin),
        .pcpin(pcpin),
        .sum(sum),
        .cout(cout),
        .error(error)
    );

    // Variables to hold expected values
    reg [N-1:0] expected_sum;
    reg expected_cout;
    reg parity_check;

    // Testbench logic
    initial begin
        // Open a log file for debugging
        $dumpfile("fs_main_adder.vcd");
        $dumpvars(0, tb_fs_main_adder);

        // Randomized testing
        repeat (100) begin
            // Generate random inputs
            a = $random;
            b = $random;
            cin = $random % 2;
            pcpin = 0;
            expected_sum = a + b + cin;
            expected_cout = (({1'b0, a} + {1'b0, b} + cin) >> N) & 1;
            // Wait for a small delay to simulate propagation delay
            #15;

            // Check the outputs against expected values
            if (sum !== expected_sum || cout !== expected_cout) begin
                $display("Test failed for inputs: a=%d, b=%d, cin=%d", a, b, cin);
                $display("comp (s, cout) = (%d, %d) : golden = (%d, %d) ", sum, cout, expected_sum, expected_cout);
                // $stop;
            end 
            if (error != 1'b0) begin
                $display("Parity check failed for inputs: a=%d, b=%d, cin=%d", a, b, cin);
                $display("error = %d ", error);
                // $stop;
            end
        end

        $display("All tests passed!");
        $finish;
    end

endmodule
// synthesis translate_on