module fs_fa(
    input a,
    input b,
    input cin,
    input pcpin,
    output sum,
    output cout,
    output pcpout
);

    (* keep *) wire t1 = (a & b) | (cin & (a | b));
    assign cout = t1;
    assign sum = a ^ b ^ cin;
    (* keep *) wire cpi_bar = ~((a & b) | (cin & (a | b)));
    assign pcpout = pcpin ^ cpi_bar;
endmodule