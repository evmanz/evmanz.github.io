
module fs_reduce_mod_q (
    input  [63:0] a,        // 64-bit input A
    input  [31:0] q,        // Modulus q (at most 32 bits)
    input  [4:0] l1,        // 5-bit l1
    input  [4:0] l2,        // 5-bit l2
    input  [4:0] l3,        // 5-bit l3
    input  [4:0] omega,     // 5-bit omega
    output [31:0] b,        // 32-bit output b
    output        error     // Error signal
);
    // Parameter: beta
    localparam beta = 32;

    // Intermediate signals
    wire [63:0] A;

    assign A = a;
    wire [31:0] Al, Ah;
    assign Al = A[31:0];
    assign Ah = A[63:32];

    // modules & extra wires
    wire [31:0] stage_1_result  [3:0];
    wire [31:0] stage_1_input_1 [3:0];
    wire [31:0] stage_1_input_2 [3:0];
    wire [3:0]  stage_1_errors;

    assign stage_1_input_1[0] = Al << l1;
    assign stage_1_input_2[0] = Al << l3;

    assign stage_1_input_1[1] = stage_1_result[0];
    assign stage_1_input_2[1] = Al << l2;

    assign stage_1_input_1[2] = stage_1_result[1] << omega;
    assign stage_1_input_2[2] = Al << (beta-1);

    assign stage_1_input_1[3] = stage_1_result[2];
    assign stage_1_input_2[3] = Al;

    wire [3:0] stage_1_cout;

    genvar i;
    generate
        for (i = 0; i < 4; i = i + 1) begin : stage_1_ops
            if (i % 2 == 0) begin
                // Adders for even indices
                fs_main_adder #(.N(32)) stage_1_adder (
                    .a(stage_1_input_1[i]),
                    .b(stage_1_input_2[i]),
                    .cin(1'b0),
                    .pcpin(1'b0),
                    .sum(stage_1_result[i]),
                    .cout(stage_1_cout[i]),
                    .error(stage_1_errors[i])
                );
            end else begin
                // Subtractors for odd indices
                fs_main_adder #(.N(32)) stage_1_subtractor (
                    .a(stage_1_input_1[i]),
                    .b(~stage_1_input_2[i]),
                    .cin(1'b1),
                    .pcpin(1'b0),
                    .sum(stage_1_result[i]),
                    .cout(stage_1_cout[i]),
                    .error(stage_1_errors[i])
                );
            end
        end
    endgenerate

    wire [3:0]  stage_2_cout;
    wire [63:0] stage_2_result  [3:0];
    wire [63:0] stage_2_input_1 [3:0];
    wire [63:0] stage_2_input_2 [3:0];
    wire [3:0]  stage_2_errors;

    assign stage_2_input_1[0] = stage_1_result[3] << l1;
    assign stage_2_input_2[0] = stage_1_result[3] << l3;

    assign stage_2_input_1[1] = stage_2_result[0];
    assign stage_2_input_2[1] = stage_1_result[3] << l2;

    assign stage_2_input_1[2] = stage_2_result[1] << omega;
    assign stage_2_input_2[2] = stage_1_result[3] << (beta-1);

    assign stage_2_input_1[3] = stage_2_result[2];
    assign stage_2_input_2[3] = stage_1_result[3];

    generate
        for (i = 0; i < 4; i = i + 1) begin : stage_2_ops
            if (i == 1) begin
                // Subtractor for index 1
                fs_main_adder #(.N(64)) stage_2_subtractor (
                    .a(stage_2_input_1[i]),
                    .b(~stage_2_input_2[i]),
                    .cin(1'b1),
                    .pcpin(1'b0),
                    .sum(stage_2_result[i]),
                    .cout(stage_2_cout[i]),
                    .error(stage_2_errors[i])
                );
            end else begin
                // Adders for other indices
                fs_main_adder #(.N(64)) stage_2_adder (
                    .a(stage_2_input_1[i]),
                    .b(stage_2_input_2[i]),
                    .cin(1'b0),
                    .pcpin(1'b0),
                    .sum(stage_2_result[i]),
                    .cout(stage_2_cout[i]),
                    .error(stage_2_errors[i])
                );
            end
        end
    endgenerate

    wire [1:0]  last_stage_cout;
    wire [63:0] stage_3_input_1 [1:0];
    wire [63:0] stage_3_input_2 [1:0];
    wire [63:0] stage_3_result  [1:0];
    wire [1:0]  stage_3_errors;

    assign stage_3_input_1[0] = A;
    assign stage_3_input_2[0] = stage_2_result[3];

    assign stage_3_input_1[1] = {last_stage_cout[0], stage_3_result[0]} >> beta;
    assign stage_3_input_2[1] = {32'b0, q};

    fs_main_adder #(.N(64)) compute_b (
        .a(stage_3_input_1[0]),
        .b(stage_3_input_2[0]),
        .cin(1'b0),
        .pcpin(1'b0),
        .sum(stage_3_result[0]),
        .cout(last_stage_cout[0]),
        .error(stage_3_errors[0])
    );

    fs_main_adder #(.N(64)) adjust_when_overflow (
        .a(stage_3_input_1[1]),
        .b(~stage_3_input_2[1]),
        .cin(1'b1),
        .pcpin(1'b0),
        .sum(stage_3_result[1]),
        .cout(last_stage_cout[1]),
        .error(stage_3_errors[1])
    );

    // Conditional subtraction of q
    reg [31:0] b_temp;
    always @(*) begin
        if (stage_3_input_1[1] >= q)
            b_temp = stage_3_result[1];//shifted_b - q;
        else
            b_temp = stage_3_input_1[1];
    end
    assign b = b_temp[31:0];
    assign error = ( |stage_1_errors ) | ( |stage_2_errors ) | ( |stage_3_errors );
endmodule

module fs_reduce_mod_q_wrapper (
    input wire clk,               // Clock signal
    input wire reset,             // Reset signal
    input wire [63:0] a_in,       // 64-bit input A
    input wire [31:0] q_in,       // Modulus q (at most 32 bits)
    input wire [4:0] l1_in,       // 5-bit l1
    input wire [4:0] l2_in,       // 5-bit l2
    input wire [4:0] l3_in,       // 5-bit l3
    input wire [4:0] omega_in,    // 5-bit omega
    output wire [31:0] b_out,     // 32-bit output b
    output wire error             // Error signal
);

    // Input registers
    reg [63:0] a_reg;
    reg [31:0] q_reg;
    reg [4:0] l1_reg;
    reg [4:0] l2_reg;
    reg [4:0] l3_reg;
    reg [4:0] omega_reg;
    reg error_reg;
    wire error_wire;

    // Output register
    reg [31:0] b_reg;
    wire [31:0] b_wire;
    // Register update logic
    always @(posedge clk) begin
        if (reset) begin
            a_reg <= 64'd0;
            q_reg <= 32'd0;
            l1_reg <= 5'd0;
            l2_reg <= 5'd0;
            l3_reg <= 5'd0;
            omega_reg <= 5'd0;
            b_reg <= 32'd0;
            error_reg <= 1'b0;
        end else begin
            a_reg <= a_in;
            q_reg <= q_in;
            l1_reg <= l1_in;
            l2_reg <= l2_in;
            l3_reg <= l3_in;
            omega_reg <= omega_in;
            b_reg <= b_wire;
            error_reg <= error_wire;
        end
    end

    // Instantiate the original module
    fs_reduce_mod_q u_reduce_mod_q (
        .a(a_reg),
        .q(q_reg),
        .l1(l1_reg),
        .l2(l2_reg),
        .l3(l3_reg),
        .omega(omega_reg),
        .b(b_wire),
        .error(error_wire)
    );

    // Drive the output with the registered value
    assign b_out = b_reg;
    assign error = error_reg;
endmodule


//synopsys translate_off
module fs_montgomery_shift_reduction_tb;
    // Parameters
    parameter BETA = 32;
    parameter Q_LENGTH = 32;

    // Inputs
    reg [2*BETA-1:0] T;
    reg [Q_LENGTH-1:0] q;
    reg [4:0] l1, l2, l3;

    // Outputs
    wire [BETA-1:0] b;
    wire error;
    // primes to check
    reg [Q_LENGTH-1:0] q_list [0:50];
    reg [4:0] l1_list [0:50];
    reg [4:0] l2_list [0:50];
    reg [4:0] l3_list [0:50];

    // Instantiate the DUT (Device Under Test)
    fs_reduce_mod_q dut (
        .a(T),
        .q(q),
        .l1(l1),
        .l2(l2),
        .l3(l3),
        .omega(5'd17),
        .b(b),
        .error(error)
    );

    integer i;
    reg [BETA-1:0] a, b_in, a_mont, b_mont;
    reg [BETA-1:0] golden_out;
    reg [3*BETA-1:0] temp_mult;
    // Testbench logic
    initial begin
        // Initialize the vector of tuples
        q_list[0] = 3489660929; l1_list[0] = 14; l2_list[0] = 13; l3_list[0] = 11;
        q_list[1] = 3238002689; l1_list[1] = 14; l2_list[1] = 13; l3_list[1] = 7;
        q_list[2] = 3892314113; l1_list[2] = 14; l2_list[2] = 12; l3_list[2] = 10;
        q_list[3] = 3758358529; l1_list[3] = 14; l2_list[3] = 12; l3_list[3] = 1;
        q_list[4] = 3758227457; l1_list[4] = 14; l2_list[4] = 12; l3_list[4] = 0;
        q_list[5] = 4194304001; l1_list[5] = 14; l2_list[5] = 10; l3_list[5] = 8;
        q_list[6] = 4161011713; l1_list[6] = 14; l2_list[6] = 10; l3_list[6] = 1;
        q_list[7] = 4160880641; l1_list[7] = 14; l2_list[7] = 10; l3_list[7] = 0;
        q_list[8] = 4261675009; l1_list[8] = 14; l2_list[8] = 8; l3_list[8] = 1;
        q_list[9] = 4286709761; l1_list[9] = 14; l2_list[9] = 6; l3_list[9] = 0;
        q_list[10] = 4293918721; l1_list[10] = 14; l2_list[10] = 4; l3_list[10] = 3;
        q_list[11] = 2717908993; l1_list[11] = 13; l2_list[11] = 12; l3_list[11] = 8;
        q_list[12] = 2684485633; l1_list[12] = 13; l2_list[12] = 12; l3_list[12] = 0;
        q_list[13] = 2953838593; l1_list[13] = 13; l2_list[13] = 11; l3_list[13] = 3;
        q_list[14] = 3154640897; l1_list[14] = 13; l2_list[14] = 9; l3_list[14] = 2;
        q_list[15] = 3187802113; l1_list[15] = 13; l2_list[15] = 8; l3_list[15] = 0;
        q_list[16] = 3208642561; l1_list[16] = 13; l2_list[16] = 7; l3_list[16] = 5;
        q_list[17] = 3204710401; l1_list[17] = 13; l2_list[17] = 7; l3_list[17] = 1;
        q_list[18] = 3214934017; l1_list[18] = 13; l2_list[18] = 6; l3_list[18] = 4;
        q_list[19] = 3217555457; l1_list[19] = 13; l2_list[19] = 5; l3_list[19] = 2;
        q_list[20] = 2483027969; l1_list[20] = 12; l2_list[20] = 11; l3_list[20] = 9;
        q_list[21] = 2416181249; l1_list[21] = 12; l2_list[21] = 11; l3_list[21] = 1;
        q_list[22] = 2558525441; l1_list[22] = 12; l2_list[22] = 10; l3_list[22] = 6;
        q_list[23] = 2634022913; l1_list[23] = 12; l2_list[23] = 9; l3_list[23] = 7;
        q_list[24] = 2671771649; l1_list[24] = 12; l2_list[24] = 7; l3_list[24] = 5;
        q_list[25] = 2680160257; l1_list[25] = 12; l2_list[25] = 6; l3_list[25] = 5;
        q_list[26] = 2676228097; l1_list[26] = 12; l2_list[26] = 6; l3_list[26] = 1;
        q_list[27] = 2682388481; l1_list[27] = 12; l2_list[27] = 4; l3_list[27] = 0;
        q_list[28] = 2349858817; l1_list[28] = 11; l2_list[28] = 9; l3_list[28] = 3;
        q_list[29] = 2349334529; l1_list[29] = 11; l2_list[29] = 9; l3_list[29] = 2;
        q_list[30] = 2348941313; l1_list[30] = 11; l2_list[30] = 9; l3_list[30] = 0;
        q_list[31] = 2403336193; l1_list[31] = 11; l2_list[31] = 7; l3_list[31] = 5;
        q_list[32] = 2399666177; l1_list[32] = 11; l2_list[32] = 7; l3_list[32] = 2;
        q_list[33] = 2214854657; l1_list[33] = 10; l2_list[33] = 9; l3_list[33] = 1;
        q_list[34] = 2250244097; l1_list[34] = 10; l2_list[34] = 8; l3_list[34] = 4;
        q_list[35] = 2273574913; l1_list[35] = 10; l2_list[35] = 6; l3_list[35] = 1;
        q_list[36] = 2277769217; l1_list[36] = 10; l2_list[36] = 5; l3_list[36] = 1;
        q_list[37] = 2183135233; l1_list[37] = 9; l2_list[37] = 8; l3_list[37] = 4;
        q_list[38] = 2198863873; l1_list[38] = 9; l2_list[38] = 7; l3_list[38] = 3;
        q_list[39] = 2208301057; l1_list[39] = 9; l2_list[39] = 6; l3_list[39] = 4;
        q_list[40] = 2212495361; l1_list[40] = 9; l2_list[40] = 5; l3_list[40] = 4;
        q_list[41] = 2210529281; l1_list[41] = 9; l2_list[41] = 5; l3_list[41] = 0;
        q_list[42] = 2213806081; l1_list[42] = 9; l2_list[42] = 3; l3_list[42] = 1;
        q_list[43] = 2214461441; l1_list[43] = 9; l2_list[43] = 1; l3_list[43] = 0;
        q_list[44] = 2168455169; l1_list[44] = 8; l2_list[44] = 7; l3_list[44] = 5;
        q_list[45] = 2154823681; l1_list[45] = 6; l2_list[45] = 4; l3_list[45] = 3;
        q_list[46] = 2155610113; l1_list[46] = 6; l2_list[46] = 2; l3_list[46] = 1;
        q_list[47] = 2150891521; l1_list[47] = 5; l2_list[47] = 3; l3_list[47] = 1;
        q_list[48] = 2150760449; l1_list[48] = 5; l2_list[48] = 3; l3_list[48] = 0;
        q_list[49] = 2148794369; l1_list[49] = 4; l2_list[49] = 3; l3_list[49] = 1;
        $display("Starting testbench for montgomery_shift_reduction...");

        // Outer loop: Iterate over the vector of tuples
        for (integer j = 0; j < 50; j = j + 1) begin  
            // Initialize parameters
            q = q_list[j];
            l1 = l1_list[j];
            l2 = l2_list[j];
            l3 = l3_list[j];

            for (i = 0; i < 10; i = i + 1) begin
                a = $random % q;
                b_in = $random % q;

                // Encode into Montgomery form
                temp_mult = a << BETA;
                a_mont = temp_mult % q;
                temp_mult = b_in << BETA;
                b_mont = temp_mult % q;

                // Compute T in Montgomery form
                T = a_mont * b_mont;

                // Compute golden output
                temp_mult = (((a*b_in) % q)*(1 << BETA));
                golden_out = temp_mult % q;

                // Wait for results from DUT
                #10;

                // Check the result
                if (b !== golden_out) begin
                    $display("ERROR: Test %0d failed. Expected: %0d, Got: %0d", i + 1, golden_out, b);
                    $display("a = %0d, b = %0d", a, b_in);
                end 
                if (error) begin
                    $display("ERROR: Test %0d failed. Error signal is high.", i + 1);
                    $display("a = %0d, b = %0d", a, b_in);
                end
            end
        end
        $display("Testbench completed.");
        $finish;
    end

endmodule
//synopsys translate_on

