set sdc_version 2.1

set clock_period 2850
set half_clock_period [expr $clock_period / 2]

create_clock [get_ports clk]  -name clk  -period $clock_period
set_input_delay  -clock clk $half_clock_period [get_ports reset]
set_input_delay  -clock clk $half_clock_period [get_ports multiplicand]
set_input_delay  -clock clk $half_clock_period [get_ports multiplier]
set_input_delay  -clock clk $half_clock_period [get_ports q]
set_input_delay  -clock clk $half_clock_period [get_ports l1]
set_input_delay  -clock clk $half_clock_period [get_ports l2]
set_input_delay  -clock clk $half_clock_period [get_ports l3]
set_input_delay  -clock clk $half_clock_period [get_ports omega]
set_output_delay  -clock clk $half_clock_period [get_ports product]
set_output_delay  -clock clk $half_clock_period [get_ports error]

set_multicycle_path -setup 20 -from [get_ports reset] -to [get_pins *reg*FF*/D]
set_multicycle_path -hold 19 -from [get_ports reset] -to [get_pins *reg*FF*/D]
set_multicycle_path -setup 20 -from [get_ports reset] -to [get_pins *reg*FF*/SET*]
set_multicycle_path -hold 19 -from [get_ports reset] -to [get_pins *reg*FF*/SET*]

group_path -name GROUP_mltpcnd_REG_TO_all -from [get_pins *multiplicand_reg*FF*/CLK] -to [get_pins *reg*FF*/D]
group_path -name GROUP_q_REG_TO_all -from [get_pins *q*reg*FF*/CLK] -to [get_pins *reg*FF*/D]
group_path -name GROUP_l1_REG_TO_all -from [get_pins *l1*reg*FF*/CLK] -to [get_pins *reg*FF*/D]
group_path -name GROUP_l2_REG_TO_all -from [get_pins *l2*reg*FF*/CLK] -to [get_pins *reg*FF*/D]
group_path -name GROUP_l3_REG_TO_all -from [get_pins *l3*reg*FF*/CLK] -to [get_pins *reg*FF*/D]
group_path -name GROUP_omega_REG_TO_all -from [get_pins *omega_reg*FF*/CLK] -to [get_pins *reg*FF*/D]
group_path -name GROUP_reset_REG_TO_all -from [get_ports reset] -to [get_pins *reg*FF*/D]
