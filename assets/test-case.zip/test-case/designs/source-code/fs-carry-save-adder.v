module fs_carry_save_adder #(parameter N=64) (
    input  [N-1:0] in1,
    input  [N-1:0] in2,
    input  [N-1:0] in3,
    input         pcpin,  // Parity-check input for each bit
    output [N-1:0] sum,
    output [N-1:0] cout,
    output [N-1:0] pcpout // Parity-check output for each bit
);
    // Internal wires for cout and pcpout bits
    wire [N-1:0] cout_internal;
    wire [N-1:0] pcpout_internal;

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : fs_csa_bit
            fs_fa fs_csa (
                .a(in1[i]),
                .b(in2[i]),
                .cin(in3[i]),
                .pcpin(pcpin),
                .sum(sum[i]),
                .cout(cout_internal[i]),
                .pcpout(pcpout_internal[i])
            );
        end
    endgenerate

    // Shift cout bits left by 1 and propagate parity-check bits
    assign cout = cout_internal;
    assign pcpout = pcpout_internal;
endmodule

// synthesis translate_off
module tb_fs_carry_save_adder;

    parameter N = 64; // Number of bits for the adder

    reg [N-1:0] a;       // N-bit input a
    reg [N-1:0] b;       // N-bit input b
    reg [N-1:0] cin;     // Carry-in
    reg pcpin;           // Parity-check input

    wire [N-1:0] sum;    // N-bit sum output
    wire [N-1:0] cout;   // Carry-out
    wire [N-1:0] pcpout; // Parity-check sum output

    // DUT instantiation
    fs_carry_save_adder dut (
        .in1(a),
        .in2(b),
        .in3(cin),
        .pcpin(pcpin),
        .sum(sum),
        .cout(cout),
        .pcpout(pcpout)
    );

    // Variables to hold expected values
    reg [N-1:0] e_sum;
    reg [N-1:0] e_cout;
    reg [N-1:0] errors;

    reg [1:0] temp_sum;

    // Testbench logic
    initial begin
        // Open a log file for debugging
        $dumpfile("fs_carry_save_adder.vcd");
        $dumpvars(0, tb_fs_carry_save_adder);

        // Randomized testing
        for (integer i = 0; i < 10 ; i = i +1 ) begin
            // Generate random inputs
            a = $random;
            b = $random;
            cin = $random;
            pcpin = 0;
            #15;

            for (integer j = 0; j < N; j = j + 1) begin 
                temp_sum = a[j] + b[j] + cin[j];
                e_cout[j] = temp_sum[1];
                e_sum[j] = temp_sum[0];
                errors[j] = (cout[j] ^ (~pcpout[j])) ^ (cin[j] ^ a[j] ^ b[j] ^ sum[j]);
            end

            for (integer j = 0; j < N; j = j +1) begin
                if (errors[j] != 1'b0) begin
                    $display("Parity check failed for inputs: a=%d, b=%d, cin=%d", a, b, cin);
                    $display("error = %b ", errors);
                    // $stop;
                end
            end

            // a b ci s cout pcpin cp_bar 
            // 0 0 0  0 0    0     1
            // 0 0 1  1 0    0     1
            // 0 1 0  1 0    0     1
            // 0 1 1  0 1    0     0
            // 1 0 0  1 0    0     1
            // 1 0 1  0 1    0     0
            // 1 1 0  0 1    0     0
            // 1 1 1  1 1    0     1

            // Check the outputs against expected values
            if (sum !== e_sum || cout !== e_cout) begin
                $display("Test  %d failed for inputs: a=%d, b=%d, cin=%d", i, a, b, cin);
                $display("comp (s, cout) = (%d, %d) : golden = (%d, %d) ", sum, cout, e_sum, e_cout);
                // $stop;
            end 
            
        end

        $display("All tests passed!");
        $finish;
    end

endmodule
// synthesis translate_on